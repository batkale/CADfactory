import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

"""
Gemini AI analysis service.
API key is stored server-side in .env — never exposed to the client.
"""

import os
import json
import httpx
from typing import Optional
from dotenv import load_dotenv
from services.geometry import GeometryResult

load_dotenv()

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
GEMINI_MODEL = "gemini-2.0-flash"
GEMINI_URL = (
    f"https://generativelanguage.googleapis.com/v1beta/models/"
    f"{GEMINI_MODEL}:generateContent"
)


class GeminiError(Exception):
    pass


def _build_prompt(geom: GeometryResult, cogs_summary: dict) -> str:
    face_text = (
        f"{geom.face_count} B-Rep faces (STEP)"
        if geom.face_count
        else f"{geom.triangle_count} triangles (STL)"
    )
    assy_text = (
        f", Assembly components: {', '.join(geom.components)}"
        if geom.is_assembly and geom.components
        else ""
    )
    nearshore_100u = cogs_summary.get("nearshore_100u", "N/A")

    return f"""You are an expert hardware engineering analyst and manufacturing consultant.

REAL CAD GEOMETRY DATA (parsed directly from file — do not hallucinate):
- Format: {geom.file_format} ({geom.format_detail})
- Volume: {geom.volume_cm3} cm³ ({geom.volume_method})
- Surface area: {geom.surface_area_cm2} cm²
- Bounding box: {geom.bounding_box_mm.x} × {geom.bounding_box_mm.y} × {geom.bounding_box_mm.z} mm
- Complexity score: {geom.complexity_score}/10
- {face_text}{assy_text}
- Nearshore COGS at 100 units: ${nearshore_100u}/unit

Based ONLY on this real geometry, provide:
1. Structural integrity score (0–100) for CNC machined Al 6061-T6
2. A specific DFM (Design for Manufacturability) warning referencing actual dimensions
3. Estimated retail price (USD), gross margin health
4. Prototype cost, tooling CapEx, total seed capital ask
5. Recommended supply chain route, lead time, risk level, and 3 real supplier names
6. Exactly 3 geometry-specific engineering optimisation recommendations

Rules:
- Do NOT estimate COGS (already computed separately)
- Reference specific measurements in your DFM warning
- Suppliers must be real, specific companies
- Seed ask should reflect actual hardware startup needs

Respond ONLY with valid JSON matching this exact schema, no markdown, no preamble:
{{
  "physics": {{
    "score": 85,
    "warning": "specific DFM warning referencing dimensions",
    "status": "PASS"
  }},
  "economics": {{
    "retail": 149.99,
    "health": "STRONG",
    "gross_margin_pct": 62.5
  }},
  "capital": {{
    "prototype": 450.00,
    "capex": 5200.00,
    "total_ask": 5650.00
  }},
  "supply_chain": {{
    "lead_time": "14–18 days",
    "route": "Nearshore CNC (Turkey / E. Europe)",
    "risk": "Low",
    "suppliers": ["Xometry EU", "3D Hubs", "Protocase"]
  }},
  "optimizations": [
    "tip 1 referencing real geometry",
    "tip 2 referencing real geometry",
    "tip 3 referencing real geometry"
  ]
}}"""


def _fallback_analysis(geom: GeometryResult) -> dict:
    """Rule-based fallback when Gemini is unavailable."""
    import math
    v = geom.volume_cm3
    cs = geom.complexity_score
    bbox = geom.bounding_box_mm

    score = min(98, max(60, int(90 - cs * 2 + math.log(max(v, 0.1)) * 0.5)))
    retail = round(v * 8.5 + 45, 2)

    if cs > 7:
        warning = (
            f"High complexity ({cs}/10) — verify minimum wall thickness ≥ 0.8mm. "
            f"At {bbox.z:.1f}mm depth, undercuts likely require 5-axis or EDM."
        )
    elif cs > 4:
        warning = (
            f"Complexity {cs}/10 — check draft angles on features "
            f"deeper than {round(bbox.z * 0.3, 1)}mm. "
            f"Part envelope {bbox.x}×{bbox.y}×{bbox.z}mm fits standard 3-axis vise."
        )
    else:
        warning = (
            f"Geometry appears machinable on 3-axis. "
            f"Verify draft angles > {round(bbox.z * 0.3, 1)}mm deep. "
            f"Bounding box {bbox.x}×{bbox.y}×{bbox.z}mm — standard fixturing applies."
        )

    return {
        "physics": {"score": score, "warning": warning, "status": "ESTIMATED"},
        "economics": {
            "retail": retail,
            "health": "STRONG" if cs < 6 else "MODERATE",
            "gross_margin_pct": None,
        },
        "capital": {
            "prototype": round(380 + v * 12, 2),
            "capex": round(4200 + v * 45 * cs, 2),
            "total_ask": round(4580 + v * 57 * cs, 2),
        },
        "supply_chain": {
            "lead_time": f"{round(10 + cs * 2)} days",
            "route": (
                "Multi-source → nearshore integration"
                if geom.is_assembly
                else "Nearshore CNC (Turkey / E. Europe)"
            ),
            "risk": "Medium" if cs > 5 else "Low",
            "suppliers": (
                ["Xometry EU", "3D Hubs", "Protocase"]
                if not geom.is_assembly
                else ["Xometry EU", "3D Hubs", "Fictiv"]
            ),
        },
        "optimizations": [
            f"Volume {v} cm³ — hollow non-structural internals to reduce material ~18%.",
            (
                f"Complexity {cs}/10: redesign undercuts → ~$12/unit saving at 100+ units."
                if cs > 4
                else f"Complexity {cs}/10: well-optimised for 3-axis single setup."
            ),
            (
                "Consolidate 2–3 assembly parts into single CNC component to cut labour."
                if geom.is_assembly
                else f"At {bbox.x}×{bbox.y}mm, nearshore CNC (Turkey) optimal at 100+ units."
            ),
        ],
    }


async def analyze_geometry(geom: GeometryResult, cogs_data: dict) -> tuple[dict, bool]:
    """
    Returns (analysis_dict, ai_was_used).
    Falls back to rule-based if Gemini key missing or call fails.
    """
    if not GEMINI_API_KEY:
        return _fallback_analysis(geom), False

    nearshore = cogs_data.get("regions", {}).get("nearshore", {})
    nearshore_100u = nearshore.get("tiers", {}).get("100", {}).get("total", "N/A")

    prompt = _build_prompt(geom, {"nearshore_100u": nearshore_100u})

    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                GEMINI_URL,
                params={"key": GEMINI_API_KEY},
                json={
                    "contents": [{"parts": [{"text": prompt}]}],
                    "generationConfig": {"temperature": 0.2, "maxOutputTokens": 1024},
                },
            )
            response.raise_for_status()
            data = response.json()

        raw_text = data["candidates"][0]["content"]["parts"][0]["text"]
        # Strip markdown fences if present
        clean = raw_text.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
        result = json.loads(clean)
        return result, True

    except Exception as e:
        print(f"[Gemini] Failed: {e} — using fallback")
        return _fallback_analysis(geom), False
