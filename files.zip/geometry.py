import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

"""
Geometry parsing service.
- STL binary & ASCII → exact volume via divergence theorem
- STEP → bounding box × fill factor, B-Rep face count, assembly BOM
"""

import struct
import re
import math
import numpy as np
from typing import Optional
from dataclasses import dataclass, field


@dataclass
class BoundingBox:
    x: float
    y: float
    z: float
    min_x: float = 0.0
    min_y: float = 0.0
    min_z: float = 0.0


@dataclass
class GeometryResult:
    file_format: str
    format_detail: str
    volume_cm3: float
    surface_area_cm2: float
    volume_method: str
    confidence_interval: float
    triangle_count: Optional[int]
    face_count: Optional[int]
    bounding_box_mm: BoundingBox
    complexity_score: float
    is_assembly: bool
    components: Optional[list] = field(default=None)
    units: Optional[str] = None


def _r2(n: float) -> float:
    return round(n, 2)


# ── STL ───────────────────────────────────────────────────────

def _is_binary_stl(data: bytes) -> bool:
    if len(data) < 84:
        return False
    triangle_count = struct.unpack_from("<I", data, 80)[0]
    expected_size = 84 + triangle_count * 50
    return len(data) == expected_size and len(data) > 84


def _parse_stl_binary(data: bytes) -> tuple:
    triangle_count = struct.unpack_from("<I", data, 80)[0]
    triangles = []
    for i in range(triangle_count):
        offset = 84 + i * 50
        # skip normal (12 bytes), read 3 vertices (9 floats)
        floats = struct.unpack_from("<9f", data, offset + 12)
        v1 = floats[0:3]
        v2 = floats[3:6]
        v3 = floats[6:9]
        triangles.append((v1, v2, v3))
    return triangles, "Binary STL"


def _parse_stl_ascii(data: bytes) -> tuple:
    text = data.decode("utf-8", errors="replace")
    matches = re.findall(
        r"vertex\s+([-\d.eE+]+)\s+([-\d.eE+]+)\s+([-\d.eE+]+)", text
    )
    vertices = [(float(m[0]), float(m[1]), float(m[2])) for m in matches]
    triangles = [
        (vertices[i], vertices[i + 1], vertices[i + 2])
        for i in range(0, len(vertices) - 2, 3)
    ]
    return triangles, "ASCII STL"


def _compute_stl_metrics(triangles: list) -> tuple:
    """
    Returns (volume_mm3, surface_area_mm2, bbox, complexity_score)
    Volume via divergence theorem (signed → abs).
    SA via cross product of triangle edges.
    """
    vol = 0.0
    sa = 0.0
    min_x = min_y = min_z = math.inf
    max_x = max_y = max_z = -math.inf

    for v1, v2, v3 in triangles:
        # Signed volume contribution
        vol += (
            v1[0] * (v2[1] * v3[2] - v2[2] * v3[1])
            + v1[1] * (v2[2] * v3[0] - v2[0] * v3[2])
            + v1[2] * (v2[0] * v3[1] - v2[1] * v3[0])
        ) / 6.0

        # Surface area: |cross(edge1, edge2)| / 2
        ax, ay, az = v2[0]-v1[0], v2[1]-v1[1], v2[2]-v1[2]
        bx, by, bz = v3[0]-v1[0], v3[1]-v1[1], v3[2]-v1[2]
        cross_x = ay * bz - az * by
        cross_y = az * bx - ax * bz
        cross_z = ax * by - ay * bx
        sa += 0.5 * math.sqrt(cross_x**2 + cross_y**2 + cross_z**2)

        for v in (v1, v2, v3):
            min_x = min(min_x, v[0]); max_x = max(max_x, v[0])
            min_y = min(min_y, v[1]); max_y = max(max_y, v[1])
            min_z = min(min_z, v[2]); max_z = max(max_z, v[2])

    volume_mm3 = abs(vol)
    volume_cm3 = volume_mm3 / 1000.0
    sa_cm2 = sa / 100.0

    bbox = BoundingBox(
        x=_r2(max_x - min_x),
        y=_r2(max_y - min_y),
        z=_r2(max_z - min_z),
        min_x=min_x, min_y=min_y, min_z=min_z,
    )

    # Complexity: ratio of actual SA to equivalent sphere SA
    # sphere_sa = 4π r² where r from volume; score 1–10
    sphere_sa = 4.836 * max(volume_cm3, 0.001) ** (2 / 3)
    raw_complexity = sa_cm2 / sphere_sa
    complexity = round(min(max(raw_complexity, 1.0), 10.0), 1)

    return _r2(volume_cm3), _r2(sa_cm2), bbox, complexity


def parse_stl(data: bytes) -> GeometryResult:
    if _is_binary_stl(data):
        triangles, fmt_detail = _parse_stl_binary(data)
    else:
        triangles, fmt_detail = _parse_stl_ascii(data)

    if not triangles:
        raise ValueError("No triangles found in STL file")

    volume_cm3, sa_cm2, bbox, complexity = _compute_stl_metrics(triangles)

    return GeometryResult(
        file_format="STL",
        format_detail=fmt_detail,
        volume_cm3=volume_cm3,
        surface_area_cm2=sa_cm2,
        volume_method="Exact (divergence theorem)",
        confidence_interval=0.25,
        triangle_count=len(triangles),
        face_count=None,
        bounding_box_mm=bbox,
        complexity_score=complexity,
        is_assembly=False,
        components=None,
    )


# ── STEP ──────────────────────────────────────────────────────

def parse_step(data: bytes) -> GeometryResult:
    text = data.decode("utf-8", errors="replace")

    # Detect units
    is_inch = bool(
        re.search(r"CONVERSION_BASED_UNIT[^)]*'INCH'", text, re.IGNORECASE)
    ) and not bool(
        re.search(r"LENGTH_UNIT[^)]*MILLIMETRE", text, re.IGNORECASE)
    )
    to_mm = 25.4 if is_inch else 1.0

    # Extract all Cartesian points for bounding box
    pt_pattern = re.compile(
        r"CARTESIAN_POINT\s*\(\s*'[^']*'\s*,\s*\(\s*"
        r"([-\d.eE+]+)\s*,\s*([-\d.eE+]+)\s*,\s*([-\d.eE+]+)\s*\)",
        re.IGNORECASE,
    )
    min_x = min_y = min_z = math.inf
    max_x = max_y = max_z = -math.inf
    pt_count = 0

    for m in pt_pattern.finditer(text):
        x, y, z = float(m[1]) * to_mm, float(m[2]) * to_mm, float(m[3]) * to_mm
        min_x = min(min_x, x); max_x = max(max_x, x)
        min_y = min(min_y, y); max_y = max(max_y, y)
        min_z = min(min_z, z); max_z = max(max_z, z)
        pt_count += 1

    if pt_count == 0:
        raise ValueError("No geometry points found in STEP file")

    bbox = BoundingBox(
        x=_r2(max_x - min_x),
        y=_r2(max_y - min_y),
        z=_r2(max_z - min_z),
        min_x=min_x, min_y=min_y, min_z=min_z,
    )

    # B-Rep face count
    face_count = len(re.findall(r"ADVANCED_FACE\s*\(", text, re.IGNORECASE))

    # Assembly BOM via PRODUCT entities
    prod_pattern = re.compile(
        r"PRODUCT\s*\(\s*'([^']*)'\s*,\s*'([^']*)'", re.IGNORECASE
    )
    products = set()
    for m in prod_pattern.finditer(text):
        name = (m.group(2) or m.group(1)).strip()
        if name and len(name) > 1 and not re.match(r"^[\s\d]*$", name):
            products.add(name)
    components = [n for n in products if len(n) > 1][:12]
    is_assembly = len(components) > 1

    # Volume estimate: BBox × fill factor
    bbox_vol_cm3 = (bbox.x * bbox.y * bbox.z) / 1000.0
    aspect_ratio = max(bbox.x, bbox.y, bbox.z) / (min(bbox.x, bbox.y, bbox.z) or 1)

    if is_assembly:
        fill_factor = 0.28
    elif face_count > 50:
        fill_factor = 0.38
    elif face_count > 20:
        fill_factor = 0.48
    else:
        fill_factor = 0.62

    if aspect_ratio > 5:
        fill_factor *= 0.75

    volume_cm3 = _r2(bbox_vol_cm3 * fill_factor)

    # Surface area estimate
    bbox_sa_cm2 = 2 * (bbox.x * bbox.y + bbox.y * bbox.z + bbox.x * bbox.z) / 100.0
    sa_multiplier = min(1.0 + face_count / 30.0, 4.0)
    sa_cm2 = _r2(bbox_sa_cm2 * sa_multiplier)

    # Complexity from face count
    complexity = round(min(max(face_count / 8.0, 1.0), 10.0), 1)

    return GeometryResult(
        file_format="STEP",
        format_detail=(
            f"STEP Assembly ({len(components)} parts)" if is_assembly else "STEP Part"
        ),
        volume_cm3=volume_cm3,
        surface_area_cm2=sa_cm2,
        volume_method=f"BBox×fill({round(fill_factor * 100)}%)",
        confidence_interval=0.35,
        triangle_count=None,
        face_count=face_count,
        bounding_box_mm=bbox,
        complexity_score=complexity,
        is_assembly=is_assembly,
        components=components if components else None,
        units="inch→mm" if is_inch else "mm",
    )


# ── Entry point ───────────────────────────────────────────────

def parse_cad_file(data: bytes, filename: str) -> GeometryResult:
    ext = filename.rsplit(".", 1)[-1].lower()
    if ext == "stl":
        return parse_stl(data)
    elif ext in ("stp", "step"):
        return parse_step(data)
    else:
        raise ValueError(f"Unsupported format: .{ext}")
