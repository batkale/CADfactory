import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlalchemy.orm import Session
from typing import List
from database import get_db
import models
import schemas
import auth as auth_utils
from services import storage, geometry as geo_service, cogs as cogs_service, gemini as gemini_service

router = APIRouter(prefix="/analysis", tags=["Analysis"])


@router.post("/run", response_model=schemas.ReportOut, status_code=201)
async def run_analysis(
    req: schemas.AnalysisRequest,
    current_user: models.User = Depends(auth_utils.get_current_user),
    db: Session = Depends(get_db),
):
    # ── 1. Fetch the uploaded file record ─────────────────────
    db_file = db.query(models.UploadedFile).filter(
        models.UploadedFile.id == req.file_id,
        models.UploadedFile.user_id == current_user.id,
    ).first()
    if not db_file:
        raise HTTPException(status_code=404, detail="File not found")

    # ── 2. Read raw bytes from disk ───────────────────────────
    try:
        data = await storage.read_file(db_file.stored_filename)
    except FileNotFoundError:
        raise HTTPException(status_code=410, detail="File data no longer available on disk")

    # ── 3. Parse geometry ─────────────────────────────────────
    try:
        geom = geo_service.parse_cad_file(data, db_file.filename)
    except ValueError as e:
        raise HTTPException(status_code=422, detail=f"Geometry parse error: {e}")

    # ── 4. Compute COGS ───────────────────────────────────────
    cogs_data = cogs_service.compute_cogs(
        geom,
        material_key=req.material,
        process_key=req.process,
    )

    # ── 5. AI analysis (Gemini, server-side key) ──────────────
    ai_result, ai_used = await gemini_service.analyze_geometry(geom, cogs_data)

    # ── 6. Persist report to DB ───────────────────────────────
    report = models.Report(
        user_id=current_user.id,
        file_id=db_file.id,
        # Geometry
        file_format=geom.file_format,
        format_detail=geom.format_detail,
        volume_cm3=geom.volume_cm3,
        surface_area_cm2=geom.surface_area_cm2,
        volume_method=geom.volume_method,
        confidence_interval=geom.confidence_interval,
        triangle_count=geom.triangle_count,
        face_count=geom.face_count,
        bbox_x_mm=geom.bounding_box_mm.x,
        bbox_y_mm=geom.bounding_box_mm.y,
        bbox_z_mm=geom.bounding_box_mm.z,
        complexity_score=geom.complexity_score,
        is_assembly=geom.is_assembly,
        components=geom.components,
        # COGS
        cogs_data=cogs_data,
        # AI
        physics_score=ai_result["physics"]["score"],
        physics_warning=ai_result["physics"]["warning"],
        retail_price_usd=ai_result["economics"]["retail"],
        capital_prototype=ai_result["capital"]["prototype"],
        capital_capex=ai_result["capital"]["capex"],
        capital_total_ask=ai_result["capital"]["total_ask"],
        supply_lead_time=ai_result["supply_chain"]["lead_time"],
        supply_route=ai_result["supply_chain"]["route"],
        supply_risk=ai_result["supply_chain"]["risk"],
        suppliers=ai_result["supply_chain"]["suppliers"],
        optimizations=ai_result["optimizations"],
        ai_used=ai_used,
    )
    db.add(report)
    db.commit()
    db.refresh(report)
    return report


@router.get("/reports", response_model=List[schemas.ReportSummary])
def list_reports(
    current_user: models.User = Depends(auth_utils.get_current_user),
    db: Session = Depends(get_db),
    skip: int = 0,
    limit: int = 50,
):
    return (
        db.query(models.Report)
        .filter(models.Report.user_id == current_user.id)
        .order_by(models.Report.created_at.desc())
        .offset(skip)
        .limit(limit)
        .all()
    )


@router.get("/reports/{report_id}", response_model=schemas.ReportOut)
def get_report(
    report_id: int,
    current_user: models.User = Depends(auth_utils.get_current_user),
    db: Session = Depends(get_db),
):
    report = db.query(models.Report).filter(
        models.Report.id == report_id,
        models.Report.user_id == current_user.id,
    ).first()
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    return report


@router.delete("/reports/{report_id}", status_code=204)
def delete_report(
    report_id: int,
    current_user: models.User = Depends(auth_utils.get_current_user),
    db: Session = Depends(get_db),
):
    report = db.query(models.Report).filter(
        models.Report.id == report_id,
        models.Report.user_id == current_user.id,
    ).first()
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    db.delete(report)
    db.commit()


@router.post("/quick", status_code=200)
async def quick_analysis(
    file_id: int,
    current_user: models.User = Depends(auth_utils.get_current_user),
    db: Session = Depends(get_db),
):
    """
    Geometry + COGS only (no AI, no DB write).
    Fast preview before committing a full analysis.
    """
    db_file = db.query(models.UploadedFile).filter(
        models.UploadedFile.id == file_id,
        models.UploadedFile.user_id == current_user.id,
    ).first()
    if not db_file:
        raise HTTPException(status_code=404, detail="File not found")

    data = await storage.read_file(db_file.stored_filename)
    geom = geo_service.parse_cad_file(data, db_file.filename)
    cogs_data = cogs_service.compute_cogs(geom)

    return {
        "geometry": {
            "format": geom.file_format,
            "format_detail": geom.format_detail,
            "volume_cm3": geom.volume_cm3,
            "surface_area_cm2": geom.surface_area_cm2,
            "volume_method": geom.volume_method,
            "confidence_interval": geom.confidence_interval,
            "bounding_box_mm": {
                "x": geom.bounding_box_mm.x,
                "y": geom.bounding_box_mm.y,
                "z": geom.bounding_box_mm.z,
            },
            "complexity_score": geom.complexity_score,
            "triangle_count": geom.triangle_count,
            "face_count": geom.face_count,
            "is_assembly": geom.is_assembly,
            "components": geom.components,
        },
        "cogs": cogs_data,
    }
